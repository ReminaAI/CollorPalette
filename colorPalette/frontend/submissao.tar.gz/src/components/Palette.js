import { useState } from "react"
import { useEffect } from "react"
import styles from "../styles/palette.module.css"

export function Palette() {
    const [colors, setColors] = useState({
        color1: "red",
        color2: "black",
        color3: "grey",
        color4: "green",
        color5: "blue"
    })
    const handleGet = async () => {
        const res = await fetch("/color/palette", {
            method: "GET",
        })
        const json = await res.json()
        setColors(json)
    }
    useEffect(() => {
        window.addEventListener('keypress', handleGet)
        return () => {
            window.removeEventListener('keypress', handleGet)
        }
    }, [])


    return (
        <div className={styles.window}>
            <div id={styles.one} className={styles.colored} style={{ backgroundColor: colors.color1 }}></div>
            <div id={styles.two} className={styles.colored} style={{ backgroundColor: colors.color2 }}></div>
            <div id={styles.three} className={styles.colored} style={{ backgroundColor: colors.color3 }}></div>
            <div id={styles.four} className={styles.colored} style={{ backgroundColor: colors.color4 }}></div>
            <div id={styles.five} className={styles.colored} style={{ backgroundColor: colors.color5 }}></div>
        </div>
    )
}