import logo from './logo.svg';
import './App.css';
import { Palette } from './components/Palette';

function App() {
  return (
    <div className="App">
      <Palette />
    </div>
  );
}

export default App;
